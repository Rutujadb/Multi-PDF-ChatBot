# Software Requirements Specification (SRS)
## Multi-PDF ChatBot — Proof of Concept

---

**Document Version:** 1.0.0  
**Prepared By:** Principal Software Solutions Architect  
**Project Type:** Proof of Concept (PoC)  
**Date:** 2026-06-03  
**Status:** Approved for Development  

---

## Table of Contents

1. [Introduction](#1-introduction)
2. [Overall Description](#2-overall-description)
3. [System Architecture](#3-system-architecture)
4. [Functional Requirements](#4-functional-requirements)
5. [Non-Functional Requirements](#5-non-functional-requirements)
6. [External Interface Requirements](#6-external-interface-requirements)
7. [Data Requirements](#7-data-requirements)
8. [Technology Stack Specification](#8-technology-stack-specification)
9. [Module Breakdown](#9-module-breakdown)
10. [Constraints and Assumptions](#10-constraints-and-assumptions)
11. [Risks and Mitigations](#11-risks-and-mitigations)
12. [Glossary](#12-glossary)
13. [References](#13-references)

---

## 1. Introduction

### 1.1 Purpose

This Software Requirements Specification (SRS) defines the complete functional and non-functional requirements for the **Multi-PDF ChatBot**, a Proof of Concept (PoC) application. This document serves as the authoritative reference for all design, development, testing, and review activities related to this project.

### 1.2 Scope

The Multi-PDF ChatBot is a web-based conversational AI application that enables users to:

- Upload one or more PDF documents into a shared knowledge base
- Ask natural language questions that are answered using content retrieved from those PDFs
- Receive responses that cite the source document
- Maintain a persistent, context-aware conversation across multiple queries and sessions

This PoC is scoped to demonstrate core RAG (Retrieval-Augmented Generation) capabilities using free, open-source tooling wherever possible. It is **not** intended for production deployment at this stage.

### 1.3 Intended Audience

| Audience | Purpose |
|---|---|
| Development Team | Implementation reference |
| HR / Project Sponsor | Scope validation and review |
| QA / Testers | Test case derivation |
| Future Architects | Extension and scaling decisions |

### 1.4 Definitions and Acronyms

| Term | Definition |
|---|---|
| RAG | Retrieval-Augmented Generation — a technique that retrieves relevant context from a knowledge base before generating an LLM response |
| LLM | Large Language Model |
| Vector Store | A database that stores text as numerical vectors for semantic similarity search |
| Embedding | A numerical representation (vector) of text that captures its meaning |
| Chunk | A smaller segment of text split from a larger document for indexing |
| PoC | Proof of Concept |
| SRS | Software Requirements Specification |

### 1.5 Overview of Document

Section 2 covers the product perspective and user classes. Section 3 describes the system architecture. Sections 4 and 5 detail functional and non-functional requirements. Sections 6–9 specify interface, data, and technology requirements. Sections 10–13 address constraints, risks, and references.

---

## 2. Overall Description

### 2.1 Product Perspective

The Multi-PDF ChatBot is a standalone PoC application. It is not part of an existing system. It demonstrates the feasibility of building a document-aware conversational assistant using the RAG pattern with locally available, free tools.

```
┌─────────────────────────────────────────────────────┐
│                   User's Browser                    │
│              (Streamlit Web Interface)              │
└──────────────────────┬──────────────────────────────┘
                       │ HTTP (localhost)
┌──────────────────────▼──────────────────────────────┐
│               Streamlit Application                 │
│  ┌─────────────┐  ┌──────────────┐  ┌────────────┐  │
│  │ PDF Upload  │  │  Chat UI     │  │  Sidebar   │  │
│  │  Module     │  │  Module      │  │  Controls  │  │
│  └──────┬──────┘  └──────┬───────┘  └────────────┘  │
│         │                │                           │
│  ┌──────▼──────┐  ┌──────▼───────┐                  │
│  │  PDF        │  │  RAG Chain   │                  │
│  │  Processor  │  │  + Memory    │                  │
│  └──────┬──────┘  └──────┬───────┘                  │
│         │                │                           │
│  ┌──────▼────────────────▼───────┐                  │
│  │         Vector Store          │                  │
│  │    (ChromaDB / Pinecone)      │                  │
│  └───────────────────────────────┘                  │
│                                                      │
│  ┌───────────────────────────────┐                  │
│  │  Embedding Model              │                  │
│  │  (HuggingFace all-MiniLM)     │                  │
│  └───────────────────────────────┘                  │
│                                                      │
│  ┌───────────────────────────────┐                  │
│  │  LLM                          │                  │
│  │  (Gemini 2.0 Flash /          │                  │
│  │   OpenRouter)                 │                  │
│  └───────────────────────────────┘                  │
└─────────────────────────────────────────────────────┘
```

### 2.2 Product Functions — Summary

- **PDF Ingestion:** Accept multiple PDF files, extract text, split into chunks, generate embeddings, and persist in a vector store.
- **Semantic Retrieval:** Convert user queries into embeddings, find the top-k most relevant chunks from the vector store.
- **Answer Generation:** Pass retrieved chunks and the user query to an LLM to generate a grounded, cited response.
- **Conversation Memory:** Maintain full conversation history within a session so follow-up questions are context-aware.
- **Session Management:** Allow users to clear chat history or fully reset the session (removing uploaded PDFs from memory).
- **Source Attribution:** Display the name of the PDF from which each answer was derived.

### 2.3 User Classes and Characteristics

| User Class | Description | Technical Level |
|---|---|---|
| End User | Uploads PDFs, asks questions, reads answers | Non-technical |
| Developer / PoC Reviewer | Runs locally, evaluates code quality and architecture | Technical |
| HR / Project Sponsor | Reviews the demo output | Non-technical |

### 2.4 Operating Environment

- **Deployment:** Local machine (localhost)
- **OS:** Windows 10+, macOS 10.15+, Ubuntu 20.04+
- **Python Version:** 3.10 or higher
- **Browser:** Any modern browser (Chrome, Firefox, Edge, Safari)
- **Internet:** Required for LLM API calls (Gemini / OpenRouter) and initial HuggingFace model download

### 2.5 Design and Implementation Constraints

- The application must be buildable entirely using **free-tier** tools and APIs for the PoC phase.
- No paid cloud infrastructure is required.
- HuggingFace embeddings must run **locally** — no API key required.
- The Gemini 2.0 Flash free tier via Google AI Studio is the primary LLM.
- ChromaDB is the primary vector store (local, persistent).
- Pinecone is included as a configurable alternative but not the default.

---

## 3. System Architecture

### 3.1 Architectural Pattern

The system follows a **Retrieval-Augmented Generation (RAG)** pipeline pattern, implemented as a single-process Python web application using Streamlit.

### 3.2 Two-Phase Pipeline

#### Phase 1 — Indexing (Triggered on PDF upload)

```
PDF Files
   │
   ▼
Text Extraction        (PyPDFLoader per file)
   │
   ▼
Text Chunking          (RecursiveCharacterTextSplitter)
   │                    chunk_size=500, overlap=50
   ▼
Embedding Generation   (HuggingFace all-MiniLM-L6-v2)
   │                    384-dimensional vectors
   ▼
Vector Store Write     (ChromaDB — persisted to disk)
   │                    + metadata: {source: filename.pdf}
   ▼
Retriever Created      (similarity search, top-k=4)
```

#### Phase 2 — Query (Triggered on each user message)

```
User Question
   │
   ▼
Question Embedding     (same HuggingFace model)
   │
   ▼
Similarity Search      (ChromaDB retriever)
   │                    returns top-k relevant chunks
   ▼
Prompt Construction    (LangChain ConversationalRetrievalChain)
   │                    context chunks + chat history + question
   ▼
LLM Generation         (Gemini 2.0 Flash)
   │
   ▼
Response + Source      (answer text + source PDF name)
   │
   ▼
Memory Update          (ConversationBufferMemory)
   │
   ▼
Display in Chat UI     (Streamlit st.chat_message)
```

### 3.3 Module Architecture

```
multi-pdf-chatbot/
│
├── app.py                  # Main Streamlit entry point
├── pdf_processor.py        # PDF loading, text extraction, chunking
├── vector_store.py         # ChromaDB / Pinecone setup and retriever
├── rag_chain.py            # LangChain RAG chain + memory
├── config.py               # Centralised configuration constants
├── utils.py                # Helper utilities (logging, formatting)
│
├── chroma_db/              # Persisted ChromaDB data (auto-created)
├── .env                    # API keys (not committed to version control)
├── .env.example            # Template for environment variables
├── requirements.txt        # All Python dependencies
├── CLAUDE.md               # Claude Code project context file
├── SRS.md                  # This document
├── PLAN.md                 # Development plan
└── README.md               # Setup and usage instructions
```

---

## 4. Functional Requirements

Requirements are categorised by module. Each requirement has a unique ID, priority (P1 = Must Have, P2 = Should Have, P3 = Nice to Have), and acceptance criteria.

---

### 4.1 PDF Upload and Management (FR-PDF)

#### FR-PDF-01 — Multiple PDF Upload
- **Priority:** P1
- **Description:** The system shall allow users to upload one or more PDF files simultaneously through a file uploader widget in the sidebar.
- **Acceptance Criteria:**
  - File uploader accepts `.pdf` extension only
  - Multiple files can be selected in a single upload action
  - Uploaded filenames are displayed in the sidebar after selection
  - Files up to 200 MB per file are accepted

#### FR-PDF-02 — PDF Text Extraction
- **Priority:** P1
- **Description:** The system shall extract all readable text from each uploaded PDF file.
- **Acceptance Criteria:**
  - Text is successfully extracted from standard text-based PDFs
  - Each page's text is extracted in reading order
  - If a PDF has no extractable text (scanned image-only), the system displays a clear warning message and skips that file

#### FR-PDF-03 — Text Chunking
- **Priority:** P1
- **Description:** The system shall split extracted text into overlapping chunks for indexing.
- **Acceptance Criteria:**
  - Default chunk size is 500 characters
  - Default overlap is 50 characters
  - Each chunk retains metadata: `source` (filename), `page` (page number)
  - Chunks do not split in the middle of a sentence where avoidable (RecursiveCharacterTextSplitter handles this)

#### FR-PDF-04 — Source Metadata Tagging
- **Priority:** P1
- **Description:** Each text chunk shall be tagged with the name of its originating PDF file.
- **Acceptance Criteria:**
  - `metadata["source"]` contains the exact filename (e.g., `report_2024.pdf`)
  - `metadata["page"]` contains the page number of origin
  - Metadata is preserved through embedding and retrieval

#### FR-PDF-05 — Duplicate PDF Handling
- **Priority:** P2
- **Description:** If a user uploads a PDF that has already been processed and stored, the system shall detect and skip re-processing.
- **Acceptance Criteria:**
  - Detection is based on filename match in existing vector store metadata
  - User is notified via an info message: "X file(s) already indexed, skipped."

---

### 4.2 Vector Store and Embeddings (FR-VS)

#### FR-VS-01 — Embedding Generation
- **Priority:** P1
- **Description:** The system shall generate vector embeddings for all text chunks using the HuggingFace `all-MiniLM-L6-v2` model.
- **Acceptance Criteria:**
  - Embeddings are generated locally with no external API call
  - Model is downloaded automatically on first run
  - Embedding dimension is 384
  - No API key is required for this step

#### FR-VS-02 — ChromaDB Persistence
- **Priority:** P1
- **Description:** The system shall persist the vector store to a local directory (`./chroma_db/`) so that data survives application restarts.
- **Acceptance Criteria:**
  - ChromaDB data is written to disk on each `add_documents()` call
  - On application start, existing ChromaDB data is automatically loaded if present
  - Users do not need to re-upload PDFs after restarting the app (if vector store exists)

#### FR-VS-03 — Semantic Retrieval
- **Priority:** P1
- **Description:** The system shall retrieve the top-4 most semantically similar chunks for any given query using cosine similarity.
- **Acceptance Criteria:**
  - Retrieval returns exactly `k=4` chunks (configurable via `config.py`)
  - Retrieved chunks come from across all indexed PDFs (not limited to one file)
  - Retrieval completes within 3 seconds for a store with up to 10,000 chunks

#### FR-VS-04 — Pinecone Alternative (Optional)
- **Priority:** P3
- **Description:** The system shall support Pinecone as a configurable alternative to ChromaDB via an environment variable flag.
- **Acceptance Criteria:**
  - Setting `VECTOR_STORE=pinecone` in `.env` switches to Pinecone
  - Pinecone index name and API key are configurable via `.env`
  - Default remains ChromaDB

---

### 4.3 RAG Chain and LLM (FR-RAG)

#### FR-RAG-01 — Conversational Retrieval Chain
- **Priority:** P1
- **Description:** The system shall implement a `ConversationalRetrievalChain` that combines the retriever, LLM, and memory to answer questions grounded in the uploaded PDFs.
- **Acceptance Criteria:**
  - Every answer is generated based on retrieved PDF content, not LLM general knowledge alone
  - The chain is initialised once per session and reused for all queries
  - The chain produces an answer and returns source documents with each response

#### FR-RAG-02 — Gemini 2.0 Flash Integration
- **Priority:** P1
- **Description:** The system shall use Google Gemini 2.0 Flash as the default LLM via the `ChatGoogleGenerativeAI` LangChain integration.
- **Acceptance Criteria:**
  - API key is read from the `.env` file (`GOOGLE_API_KEY`)
  - Model identifier used: `gemini-2.0-flash`
  - LLM temperature is set to `0.3` for consistent, factual responses
  - Successful response is received within 15 seconds under normal conditions

#### FR-RAG-03 — OpenRouter Alternative LLM
- **Priority:** P2
- **Description:** The system shall support OpenRouter as a configurable alternative LLM gateway.
- **Acceptance Criteria:**
  - Setting `LLM_PROVIDER=openrouter` in `.env` switches to OpenRouter
  - OpenRouter API key and model name are read from `.env`
  - The same LangChain chain interface is used regardless of LLM provider

#### FR-RAG-04 — Answer Grounding Prompt
- **Priority:** P1
- **Description:** The system shall use a structured prompt template that instructs the LLM to answer only from the retrieved context and to say "I don't know" if the answer is not in the documents.
- **Acceptance Criteria:**
  - Prompt template is defined in `config.py`
  - The template includes placeholders for: `{context}`, `{chat_history}`, `{question}`
  - LLM responses do not fabricate information not present in retrieved chunks

---

### 4.4 Conversation Memory (FR-MEM)

#### FR-MEM-01 — Session-Scoped Conversation History
- **Priority:** P1
- **Description:** The system shall maintain a full conversation history within a user session so that follow-up questions are answered with awareness of prior exchanges.
- **Acceptance Criteria:**
  - All user messages and assistant responses are stored in `st.session_state`
  - The `ConversationBufferMemory` is populated with the full history on every chain invocation
  - The chat history is displayed chronologically in the UI

#### FR-MEM-02 — Follow-up Question Handling
- **Priority:** P1
- **Description:** The system shall correctly resolve references in follow-up questions (e.g., "What else did he say?" referring to a person named in a previous answer).
- **Acceptance Criteria:**
  - LangChain's `ConversationalRetrievalChain` condenses the follow-up with history into a standalone question before retrieval
  - The standalone question is used for vector search (not the raw follow-up)

#### FR-MEM-03 — Clear Chat
- **Priority:** P1
- **Description:** The system shall provide a "Clear Chat" button that removes all chat history from the current session without removing the indexed vector store.
- **Acceptance Criteria:**
  - Clicking "Clear Chat" empties `st.session_state.messages` and `st.session_state.memory`
  - The vector store and uploaded PDF index are preserved
  - The user can immediately start a new conversation after clearing

#### FR-MEM-04 — Reset Session
- **Priority:** P1
- **Description:** The system shall provide a "Reset Session" button that clears both the chat history and the in-memory knowledge of uploaded PDFs, effectively returning the app to its initial state.
- **Acceptance Criteria:**
  - Clicking "Reset Session" clears chat history, session state, and the ChromaDB collection (in-memory reference only — persisted data on disk is optionally cleared based on a config flag)
  - User must re-upload and re-process PDFs after a reset

---

### 4.5 Chat Interface (FR-UI)

#### FR-UI-01 — Chat Message Display
- **Priority:** P1
- **Description:** The system shall display all messages in a standard chat format, clearly distinguishing between user messages and assistant responses.
- **Acceptance Criteria:**
  - User messages appear with a "user" role avatar/label
  - Assistant messages appear with an "assistant" role avatar/label
  - Messages are ordered chronologically (oldest at top, newest at bottom)
  - `st.chat_message()` is used for rendering

#### FR-UI-02 — Chat Input Field
- **Priority:** P1
- **Description:** The system shall provide a persistent chat input field at the bottom of the page for users to type their questions.
- **Acceptance Criteria:**
  - `st.chat_input()` is used
  - Input field is disabled (with a tooltip) if no PDFs have been processed yet
  - Pressing Enter or clicking the send button submits the query

#### FR-UI-03 — Source Citation Display
- **Priority:** P1
- **Description:** The system shall display the name of the source PDF(s) below each assistant response.
- **Acceptance Criteria:**
  - Source filenames are shown as a formatted label below each answer (e.g., `📄 Source: report_2024.pdf, manual.pdf`)
  - If multiple PDFs contributed, all unique source names are listed
  - Source is derived from `document.metadata["source"]` of retrieved chunks

#### FR-UI-04 — Processing Spinner
- **Priority:** P1
- **Description:** The system shall display a loading spinner during PDF processing and during LLM response generation.
- **Acceptance Criteria:**
  - `st.spinner("Processing PDFs...")` is shown during indexing
  - `st.spinner("Generating answer...")` is shown during LLM calls
  - The spinner disappears when the operation completes

#### FR-UI-05 — Sidebar Layout
- **Priority:** P1
- **Description:** The system shall use the Streamlit sidebar to house all controls that are not part of the main chat flow.
- **Acceptance Criteria:**
  - Sidebar contains: PDF uploader, "Process PDFs" button, list of indexed PDFs, "Clear Chat" button, "Reset Session" button
  - Main content area contains only the chat interface

#### FR-UI-06 — Indexed PDF List Display
- **Priority:** P2
- **Description:** The system shall display the list of currently indexed PDFs in the sidebar.
- **Acceptance Criteria:**
  - Each indexed PDF filename is listed with a checkmark icon
  - The list updates when new PDFs are processed

#### FR-UI-07 — Empty State Messaging
- **Priority:** P2
- **Description:** When no PDFs have been processed, the system shall display a clear instructional message in the chat area.
- **Acceptance Criteria:**
  - A message such as "Upload PDFs in the sidebar to get started" is displayed
  - The chat input is disabled until at least one PDF is processed

---

### 4.6 Configuration and Environment (FR-CFG)

#### FR-CFG-01 — Environment Variable Management
- **Priority:** P1
- **Description:** All sensitive credentials and configurable parameters shall be managed via a `.env` file loaded at startup.
- **Acceptance Criteria:**
  - `.env` file is read using `python-dotenv`
  - `.env` is listed in `.gitignore`
  - `.env.example` is committed with placeholder values and comments

#### FR-CFG-02 — Centralised Configuration
- **Priority:** P1
- **Description:** All application constants (chunk size, overlap, k value, model names, persist directory) shall be defined in a single `config.py` file.
- **Acceptance Criteria:**
  - No magic numbers or hardcoded strings outside of `config.py`
  - Changing a value in `config.py` changes the behaviour throughout the app without any other code changes

---

## 5. Non-Functional Requirements

### 5.1 Performance

| ID | Requirement | Target |
|---|---|---|
| NFR-PERF-01 | PDF processing time (per page) | ≤ 2 seconds per page |
| NFR-PERF-02 | Vector store retrieval time | ≤ 3 seconds for up to 10,000 chunks |
| NFR-PERF-03 | End-to-end response time (query to answer) | ≤ 15 seconds under normal network conditions |
| NFR-PERF-04 | App startup time | ≤ 10 seconds (excluding first-time model download) |

### 5.2 Reliability

| ID | Requirement |
|---|---|
| NFR-REL-01 | The application shall not crash on malformed or password-protected PDFs; it shall display an error and continue |
| NFR-REL-02 | The ChromaDB vector store shall survive application restarts without data loss |
| NFR-REL-03 | All API calls shall be wrapped in try/except with user-facing error messages |

### 5.3 Usability

| ID | Requirement |
|---|---|
| NFR-USE-01 | A non-technical user shall be able to upload PDFs and ask their first question within 2 minutes of opening the app |
| NFR-USE-02 | Error messages shall be written in plain English, not technical stack traces |
| NFR-USE-03 | All buttons shall have clear, action-oriented labels |

### 5.4 Maintainability

| ID | Requirement |
|---|---|
| NFR-MNT-01 | Each Python module shall have a single, clearly defined responsibility (Single Responsibility Principle) |
| NFR-MNT-02 | All functions shall have docstrings describing purpose, parameters, and return values |
| NFR-MNT-03 | Code shall follow PEP 8 style conventions |
| NFR-MNT-04 | Switching the LLM provider or vector store shall require changes only in `config.py` and `.env`, not in core logic |

### 5.5 Security

| ID | Requirement |
|---|---|
| NFR-SEC-01 | API keys shall never be hardcoded in source files |
| NFR-SEC-02 | `.env` shall be excluded from version control via `.gitignore` |
| NFR-SEC-03 | Uploaded PDFs shall be stored only in memory (not written to disk) during this PoC phase |

### 5.6 Scalability (PoC Scope)

| ID | Requirement |
|---|---|
| NFR-SCA-01 | The system shall handle up to 10 PDF files totalling 500 pages within this PoC scope |
| NFR-SCA-02 | The architecture shall be designed such that switching to Pinecone (cloud) enables scaling beyond these limits without re-architecting the application |

---

## 6. External Interface Requirements

### 6.1 User Interface

- Built entirely with **Streamlit** (`streamlit >= 1.35.0`)
- No custom HTML, CSS, or JavaScript is required for the PoC
- Responsive to standard desktop browser window sizes
- Layout: two-column (sidebar + main chat area)

### 6.2 Software Interfaces

| Interface | Library | Purpose |
|---|---|---|
| PDF Loading | `langchain-community` PyPDFLoader | Extract text from PDFs |
| Text Splitting | `langchain-text-splitters` | Chunk text |
| Embeddings | `sentence-transformers` | Local vector generation |
| Vector Store | `chromadb` | Store and retrieve embeddings |
| LLM (primary) | `langchain-google-genai` | Gemini 2.0 Flash API |
| LLM (secondary) | `langchain-openai` (OpenRouter) | Alternative LLM gateway |
| Memory | `langchain` ConversationBufferMemory | Chat history |
| Chain | `langchain` ConversationalRetrievalChain | Full RAG pipeline |
| Env Management | `python-dotenv` | Load `.env` variables |

### 6.3 Communication Interfaces

- **LLM API calls** go over HTTPS to `generativelanguage.googleapis.com` (Gemini) or `openrouter.ai` (OpenRouter)
- **HuggingFace model download** happens over HTTPS from `huggingface.co` on first run only; subsequent runs use the local cache
- **ChromaDB** operates entirely on the local filesystem — no network calls

---

## 7. Data Requirements

### 7.1 Input Data

| Data | Format | Source | Constraints |
|---|---|---|---|
| PDF files | `.pdf` | User upload | Text-based PDFs only; max 200 MB per file |
| User queries | Plain text string | Chat input | Max 2000 characters per query |
| API keys | String | `.env` file | Must be valid for Gemini or OpenRouter |

### 7.2 Stored Data

| Data | Storage | Format | Lifetime |
|---|---|---|---|
| Text chunk embeddings | ChromaDB (`./chroma_db/`) | Binary vector format | Persistent until manual deletion |
| Chunk metadata | ChromaDB | Key-value (source, page) | Persistent until manual deletion |
| Chat history | `st.session_state` | Python list of dicts | Session-scoped (lost on browser refresh) |
| HuggingFace model | Local cache (`~/.cache/huggingface/`) | Binary model files | Persistent |

### 7.3 Output Data

| Data | Format | Destination |
|---|---|---|
| LLM-generated answers | Plain text | Streamlit chat UI |
| Source citations | Formatted string (filename list) | Below each chat response |
| Processing status messages | Info/success/warning messages | Streamlit sidebar / main area |

---

## 8. Technology Stack Specification

### 8.1 Core Dependencies

```
# requirements.txt

# UI
streamlit>=1.35.0

# LangChain core
langchain>=0.2.0
langchain-community>=0.2.0
langchain-text-splitters>=0.2.0

# PDF processing
pypdf>=4.0.0

# Embeddings (local, no API key)
sentence-transformers>=2.7.0

# Vector store - primary
chromadb>=0.5.0

# Vector store - alternative (optional)
pinecone-client>=3.0.0

# LLM - primary
langchain-google-genai>=1.0.0
google-generativeai>=0.7.0

# LLM - alternative (optional)
langchain-openai>=0.1.0

# Environment management
python-dotenv>=1.0.0
```

### 8.2 Environment Variables

```
# .env.example

# --- LLM Configuration ---
LLM_PROVIDER=gemini                    # Options: gemini | openrouter
GOOGLE_API_KEY=your_google_api_key_here

# --- OpenRouter (if LLM_PROVIDER=openrouter) ---
OPENROUTER_API_KEY=your_openrouter_api_key_here
OPENROUTER_MODEL=mistralai/mistral-7b-instruct

# --- Vector Store Configuration ---
VECTOR_STORE=chroma                    # Options: chroma | pinecone

# --- Pinecone (if VECTOR_STORE=pinecone) ---
PINECONE_API_KEY=your_pinecone_api_key_here
PINECONE_INDEX_NAME=multi-pdf-chatbot
```

### 8.3 Configuration Constants

```python
# config.py — all defaults

# Chunking
CHUNK_SIZE = 500
CHUNK_OVERLAP = 50

# Retrieval
TOP_K_RESULTS = 4

# ChromaDB
CHROMA_PERSIST_DIR = "./chroma_db"
CHROMA_COLLECTION_NAME = "multi_pdf_store"

# Embedding model
EMBEDDING_MODEL_NAME = "all-MiniLM-L6-v2"

# LLM
GEMINI_MODEL_NAME = "gemini-2.0-flash"
LLM_TEMPERATURE = 0.3
LLM_MAX_TOKENS = 1024

# Prompt template
SYSTEM_PROMPT = """You are a helpful assistant that answers questions 
based strictly on the provided document context. If the answer is not 
in the context, say "I don't have enough information in the uploaded 
documents to answer this." Do not use any external knowledge.

Context:
{context}

Chat History:
{chat_history}

Question: {question}
Answer:"""
```

---

## 9. Module Breakdown

### 9.1 `app.py` — Main Application Entry Point

**Responsibilities:**
- Initialise Streamlit page configuration
- Manage `st.session_state` lifecycle
- Render sidebar (upload, controls)
- Render main chat interface
- Orchestrate calls to `pdf_processor`, `vector_store`, and `rag_chain`

**Key Functions:**
- `initialise_session_state()` — Set up all session state keys
- `render_sidebar()` — PDF uploader, process button, controls
- `render_chat()` — Display chat history and handle new input
- `handle_query(user_input)` — Call RAG chain and display result

---

### 9.2 `pdf_processor.py` — PDF Ingestion Pipeline

**Responsibilities:**
- Load PDF files from Streamlit's `UploadedFile` objects
- Extract text using `PyPDFLoader`
- Split text into chunks using `RecursiveCharacterTextSplitter`
- Attach source metadata to each chunk

**Key Functions:**
- `load_and_split_pdfs(uploaded_files) -> List[Document]`
- `get_text_chunks(documents) -> List[Document]`

---

### 9.3 `vector_store.py` — Embedding and Storage

**Responsibilities:**
- Generate embeddings using HuggingFace model
- Create or load ChromaDB vector store
- Provide retriever interface to the RAG chain
- Support Pinecone as alternative (via config)

**Key Functions:**
- `get_embeddings() -> HuggingFaceEmbeddings`
- `create_vector_store(chunks) -> VectorStore`
- `load_vector_store() -> VectorStore`
- `get_retriever(vector_store) -> BaseRetriever`

---

### 9.4 `rag_chain.py` — Retrieval-Augmented Generation Chain

**Responsibilities:**
- Initialise the LLM (Gemini or OpenRouter)
- Set up conversation memory
- Build the `ConversationalRetrievalChain`
- Invoke the chain and extract answer + source documents

**Key Functions:**
- `get_llm() -> BaseLanguageModel`
- `get_memory() -> ConversationBufferMemory`
- `build_rag_chain(retriever, memory) -> ConversationalRetrievalChain`
- `query_chain(chain, question) -> dict`

---

### 9.5 `config.py` — Configuration Constants

**Responsibilities:**
- Define all application constants
- Load and expose environment variables
- Define the prompt template

---

### 9.6 `utils.py` — Helper Utilities

**Responsibilities:**
- Format source document citations for display
- Validate uploaded file types
- Log debug information

**Key Functions:**
- `format_sources(source_documents) -> str`
- `validate_pdf_files(files) -> Tuple[List, List]`

---

## 10. Constraints and Assumptions

### 10.1 Constraints

1. The application runs on a **single machine** (localhost) — no multi-user support in this PoC.
2. PDFs must contain **selectable/copyable text** — scanned image PDFs are not supported without OCR (out of scope for PoC).
3. The HuggingFace model download (~90 MB) requires an internet connection on **first run only**.
4. The Gemini 2.0 Flash free tier has rate limits (15 requests/minute, 1 million tokens/day) — heavy usage may hit limits.
5. ChromaDB is not designed for concurrent multi-user write access — acceptable for a single-user PoC.
6. Session state (chat history) is **not persistent** across browser refreshes in the PoC.

### 10.2 Assumptions

1. The developer has Python 3.10+ installed on their machine.
2. A valid Google AI Studio API key is available at no cost.
3. The PDFs used for testing are in English and contain standard readable text.
4. The development machine has at least 4 GB of RAM available.
5. pip and virtualenv are available for dependency management.

---

## 11. Risks and Mitigations

| Risk | Probability | Impact | Mitigation |
|---|---|---|---|
| Gemini API rate limit exceeded | Medium | High | Cache responses; add retry logic with exponential backoff; switch to OpenRouter if needed |
| HuggingFace model fails to download | Low | High | Document offline fallback; allow manual model path config |
| PDF has no extractable text | Medium | Medium | Validate on upload; skip invalid files with user warning |
| ChromaDB data corruption on unclean shutdown | Low | Medium | Use ChromaDB's built-in WAL; document recovery steps in README |
| LangChain API breaking changes | Medium | High | Pin exact dependency versions in requirements.txt |
| Session state lost on browser refresh | High | Low | Document this known limitation; considered acceptable for PoC |

---

## 12. Glossary

| Term | Definition |
|---|---|
| Chunk | A segment of text (default 500 chars) split from a larger document for vector indexing |
| ChromaDB | An open-source, local-first vector database |
| ConversationalRetrievalChain | A LangChain chain that condenses chat history + new question before retrieval |
| ConversationBufferMemory | A LangChain memory class that stores the full conversation history as a buffer |
| Embedding | A fixed-size numerical vector representing the semantic meaning of a text chunk |
| Gemini 2.0 Flash | Google's fast, free-tier LLM available via Google AI Studio |
| HuggingFace all-MiniLM-L6-v2 | A lightweight, local sentence transformer model producing 384-dim embeddings |
| LangChain | A Python framework for building LLM-powered applications |
| OpenRouter | An API gateway providing access to multiple LLMs through a unified interface |
| Pinecone | A managed, cloud-hosted vector database service |
| PyPDFLoader | A LangChain document loader for extracting text from PDF files |
| RAG | Retrieval-Augmented Generation — augmenting LLM prompts with retrieved context |
| RecursiveCharacterTextSplitter | A LangChain text splitter that splits on paragraph, sentence, and character boundaries recursively |
| Retriever | A LangChain interface that accepts a query and returns relevant documents |
| Semantic Search | Similarity search based on meaning (vector distance) rather than keyword matching |
| Streamlit | A Python library for building web applications with pure Python |
| Vector Store | A database optimised for storing and querying high-dimensional vectors |

---

## 13. References

| Resource | URL |
|---|---|
| LangChain RAG Concepts | https://python.langchain.com/docs/concepts/rag |
| RAG from Scratch (LangChain GitHub) | https://github.com/langchain-ai/rag-from-scratch |
| LangChain Official Docs | https://python.langchain.com/docs/get_started/introduction |
| ChromaDB Getting Started | https://docs.trychroma.com/docs/overview/getting-started |
| ChromaDB Cookbook | https://cookbook.chromadb.dev |
| Pinecone Docs | https://docs.pinecone.io |
| LangChain + Pinecone Integration | https://python.langchain.com/docs/integrations/vectorstores/pinecone |
| Streamlit Official Docs | https://docs.streamlit.io |
| Google AI Studio (Gemini API Key) | https://aistudio.google.com |
| Gemini Quickstart | https://ai.google.dev/gemini-api/docs/quickstart |
| ChatGoogleGenerativeAI Docs | https://docs.langchain.com/oss/python/integrations/chat/google_generative_ai |
| OpenRouter Homepage | https://openrouter.ai |
| HuggingFace all-MiniLM-L6-v2 | https://huggingface.co/sentence-transformers/all-MiniLM-L6-v2 |
| Krish Naik RAG Crash Course | https://www.classcentral.com/course/youtube-complete-rag-crash-course-with-langchain-in-2-hours-488732 |

---

*End of SRS Document — Version 1.0.0*
